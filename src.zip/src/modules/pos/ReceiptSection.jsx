import React from 'react';
import { formatRupiah } from '../../core/formatters';

export function ReceiptSection({ items, removeItem, totalAmount, paymentState, updatePayment, onConfirmPayment }) {
    const { mode, amountPaid, isLocked } = paymentState || {};

    // Calculate Change
    const paid = parseFloat(amountPaid) || 0;
    const change = Math.max(0, paid - totalAmount);
    const isTunai = mode === 'TUNAI';

    // Validation
    const canCheckout = items.length > 0 && (!isTunai || paid >= totalAmount);

    const renderSummary = () => (
        <div className="total-summary">
            <div className="summary-row total">
                <span>{isLocked ? 'TOTAL BAYAR' : 'TOTAL'}</span>
                <span className="amount">{formatRupiah(totalAmount)}</span>
            </div>
            {isTunai && (
                <>
                    <div className="summary-row">
                        <span>DIBAYAR</span>
                        <span>{formatRupiah(paid)}</span>
                    </div>
                    <div className="summary-row change">
                        <span>KEMBALI</span>
                        <span>{formatRupiah(change)}</span>
                    </div>
                </>
            )}
        </div>
    );

    const handlePrint = () => {
        console.log('SHOWING NOTA PREVIEW');
        console.table(items);
        console.log('TOTAL:', totalAmount);
        updatePayment({ showNotaPreview: true });
    };

    return (
        <div className="receipt-section">
            <div className="receipt-header">
                <h2>JOGLO PRINTING</h2>
                <div className="store-info">
                    <p>Jl. Diponegoro, Rw. 4, Jogoloyo</p>
                    <p>Demak, Jawa Tengah</p>
                    <p>Telp: 0813-9028-6826</p>
                    <p className="highlight">Buka 24 Jam</p>
                </div>
                <div className="divider"></div>
            </div>

            <div className="receipt-items">
                {items.length === 0 && <div className="empty-state">Cart Kosong</div>}

                {items.map((item) => {
                    // Standardized Data Structure Mapping
                    const { id, productName, dimensions, pricingType, qty, totalPrice, finishings } = item;
                    // Fallback for safety
                    const { length, width, sizeKey } = dimensions || {};

                    return (
                        <div key={id} className="receipt-item-card" style={{ opacity: isLocked ? 0.7 : 1 }}>
                            <div className="item-info">
                                <div className="item-name">{productName}</div>
                                <div className="item-details">
                                    {(pricingType === 'AREA' || pricingType === 'CUSTOM') && length && width && (
                                        <span className="dim-badge">{length}m x {width}m</span>
                                    )}
                                    {pricingType === 'LINEAR' && length && (
                                        <span className="dim-badge">{length}m</span>
                                    )}
                                    {pricingType === 'MATRIX' && sizeKey && (
                                        <span className="size-badge">{sizeKey}</span>
                                    )}
                                    {pricingType === 'MANUAL' && (
                                        <span className="manual-badge">-</span>
                                    )}
                                    <span className="qty-badge">{qty} pcs</span>
                                </div>

                                {finishings && finishings.length > 0 && (
                                    <div className="item-finishings">
                                        {finishings.map((f, idx) => (
                                            <span key={idx} className="fin-pill">+ {f.name}</span>
                                        ))}
                                    </div>
                                )}
                            </div>
                            <div className="item-meta">
                                <div className="item-price">
                                    {formatRupiah(totalPrice)}
                                </div>
                                {!isLocked && <button className="btn-delete" onClick={() => removeItem(id)}>✕</button>}
                            </div>
                        </div>
                    );
                })}
            </div>

            <div className="receipt-footer">
                {!isLocked ? (
                    <>
                        <div className="payment-controls">
                            <div className="payment-mode-switch">
                                <button
                                    className={`mode-btn ${mode === 'TUNAI' ? 'active' : ''}`}
                                    onClick={() => updatePayment({ mode: 'TUNAI' })}
                                >
                                    TUNAI
                                </button>
                                <button
                                    className={`mode-btn ${mode === 'NON_TUNAI' ? 'active' : ''}`}
                                    onClick={() => updatePayment({ mode: 'NON_TUNAI' })}
                                >
                                    NON TUNAI
                                </button>
                            </div>

                            {isTunai && (
                                <div className="payment-input-row">
                                    <label>Uang Diterima</label>
                                    <input
                                        type="number"
                                        placeholder="0"
                                        value={amountPaid}
                                        onChange={(e) => updatePayment({ amountPaid: e.target.value })}
                                        className="pay-input"
                                    />
                                </div>
                            )}
                        </div>

                        {renderSummary()}

                        <button
                            className="btn-checkout"
                            disabled={!canCheckout}
                            onClick={() => {
                                console.log("=== PROSES PEMBAYARAN BUTTON CLICKED ===");
                                onConfirmPayment();
                            }}
                        >
                            PROSES PEMBAYARAN
                        </button>
                    </>
                ) : (
                    <div className="locked-summary">
                        <div className="status-badge">LUNAS ({mode})</div>
                        {renderSummary()}
                        <button className="btn-print" onClick={handlePrint}>
                            CETAK NOTA
                        </button>
                        <button className="btn-new" onClick={() => window.location.reload()}>
                            TRANSAKSI BARU
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
}
