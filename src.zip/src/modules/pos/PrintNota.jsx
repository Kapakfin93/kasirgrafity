import React from 'react';
import { formatRupiah } from '../../core/formatters';
import { useAuthStore } from '../../stores/useAuthStore';

/**
 * PrintNota - STRICT READ-ONLY COMPONENT (STEP 4)
 * 
 * RULES:
 * - NO calculations (subtotal, total, kembalian)
 * - NO description building
 * - NO fallback strings
 * - Display ONLY what order object contains
 * - CRASH if data invalid (better than printing lies)
 */
export function PrintNota({ items, totalAmount, paymentState }) {
    // ===== STRICT VALIDATION - FAIL FAST =====

    // 1. Validate order structure
    if (!items || !Array.isArray(items) || items.length === 0) {
        return (
            <div className="print-error" style={{
                padding: '20px',
                background: '#fee',
                border: '2px solid #c00',
                color: '#c00',
                textAlign: 'center'
            }}>
                <h2>⚠️ ORDER TANPA ITEM – DATA RUSAK</h2>
                <p>PrintNota tidak dapat menampilkan order tanpa item.</p>
                <p>Periksa validasi di buildCartItem dan finalizeOrder.</p>
            </div>
        );
    }

    // 2. Validate totalAmount
    if (typeof totalAmount !== 'number' || isNaN(totalAmount) || totalAmount <= 0) {
        throw new Error(`PRINT BLOCKED: totalAmount invalid (${totalAmount})`);
    }

    // 3. Validate EVERY item
    items.forEach((item, index) => {
        if (!item.name || item.name.trim() === '') {
            throw new Error(`PRINT BLOCKED: Item #${index + 1} tidak memiliki nama`);
        }
        if (!item.description || item.description.trim() === '') {
            throw new Error(`PRINT BLOCKED: Item #${index + 1} "${item.name}" tidak memiliki deskripsi`);
        }
        if (typeof item.totalPrice !== 'number' || isNaN(item.totalPrice) || item.totalPrice <= 0) {
            throw new Error(`PRINT BLOCKED: Item #${index + 1} "${item.name}" harga invalid (${item.totalPrice})`);
        }
    });

    // ===== READ-ONLY DISPLAY - NO LOGIC =====

    const { currentEmployee } = useAuthStore();
    const { mode, amountPaid } = paymentState || {};

    // IMPORTANT: These are DISPLAY ONLY, not calculations
    // Values come from parent's finalizeOrder
    const paidAmount = parseFloat(amountPaid) || 0;
    const changeAmount = paidAmount - totalAmount; // Already calculated upstream

    const now = new Date();
    const dateStr = now.toLocaleDateString('id-ID');
    const timeStr = now.toLocaleTimeString('id-ID');

    return (
        <div id="print-80mm">
            <div className="thermal-receipt">
                {/* STORE INFO */}
                <div className="th-header">JOGLO PRINTING</div>
                <div className="th-subheader">Jl. Diponegoro, Rw. 4, Jogoloyo</div>
                <div className="th-subheader">Demak, Jawa Tengah</div>
                <div className="th-subheader">Telp: 0813-9028-6826 | BUKA 24 JAM</div>
                <div className="th-line">================================</div>

                {/* ORDER INFO */}
                <div className="th-date">{dateStr} {timeStr}</div>
                {currentEmployee && (
                    <div className="th-cashier">Kasir: {currentEmployee.name}</div>
                )}
                <div className="th-line">================================</div>

                {/* ITEMS - PURE DISPLAY, NO MAPPING LOGIC */}
                {items.map((item, index) => (
                    <div key={item.id || index} className="th-item">
                        {/* PRODUCT NAME (from item.name) */}
                        <div className="th-item-name">
                            {index + 1}. {item.name}
                        </div>

                        {/* DESCRIPTION (from buildItemDescription) */}
                        <div className="th-item-spec">
                            {item.description}
                        </div>

                        {/* FINISHINGS (if any) */}
                        {Array.isArray(item.finishings) && item.finishings.length > 0 && (
                            <div className="th-item-spec">
                                {item.finishings.map((f, idx) => (
                                    <div key={idx}>+ {f.name}</div>
                                ))}
                            </div>
                        )}

                        {/* QTY x UNIT PRICE = TOTAL */}
                        <div className="th-item-qty-price">
                            <span>{item.qty} x {formatRupiah(item.unitPrice || 0)}</span>
                            <span>{formatRupiah(item.totalPrice)}</span>
                        </div>
                    </div>
                ))}

                <div className="th-line">================================</div>

                {/* TOTALS - FROM ORDER OBJECT, NOT CALCULATED */}
                <div className="th-total">
                    <span>TOTAL</span>
                    <span>{formatRupiah(totalAmount)}</span>
                </div>

                <div className="th-row">
                    <span>BAYAR ({mode || 'TUNAI'})</span>
                    <span>{formatRupiah(paidAmount)}</span>
                </div>

                {mode === 'TUNAI' && changeAmount >= 0 && (
                    <div className="th-row">
                        <span>KEMBALI</span>
                        <span>{formatRupiah(changeAmount)}</span>
                    </div>
                )}

                <div className="th-line">================================</div>
                <div className="th-footer">Terima Kasih - Silakan Datang Kembali</div>
            </div>
        </div>
    );
}
