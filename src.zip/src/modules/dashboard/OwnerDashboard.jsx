/**
 * OwnerDashboard Component
 * Main dashboard for owner - consumes all data
 */

import React, { useEffect, useState } from 'react';
import { useOrderStore } from '../../stores/useOrderStore';
import { useEmployeeStore } from '../../stores/useEmployeeStore';
import { useAttendanceStore } from '../../stores/useAttendanceStore';
import { usePermissions } from '../../hooks/usePermissions';
import { formatRupiah } from '../../core/formatters';
import { formatDate, formatTime, getDateRange } from '../../utils/dateHelpers';
import { StatsCard } from './StatsCard';
import { RecentOrders } from './RecentOrders';
import { TodayAttendance } from './TodayAttendance';

export function OwnerDashboard() {
    const { isOwner } = usePermissions();
    const [period, setPeriod] = useState('today'); // today | week | month

    // Stores
    const { orders, loadOrders } = useOrderStore();
    const { employees, loadEmployees, getActiveEmployees } = useEmployeeStore();
    const { todayAttendances, loadTodayAttendances } = useAttendanceStore();

    // Load data on mount
    useEffect(() => {
        loadOrders();
        loadEmployees();
        loadTodayAttendances();
    }, [loadOrders, loadEmployees, loadTodayAttendances]);

    // Check permission
    if (!isOwner) {
        return (
            <div className="access-denied">
                <h2>❌ Akses Ditolak</h2>
                <p>Hanya Owner yang bisa mengakses dashboard ini.</p>
            </div>
        );
    }

    // Get date range based on period
    const dateRange = getDateRange(period);

    // Filter orders by date range
    const filteredOrders = orders.filter(order => {
        const orderDate = new Date(order.createdAt);
        return orderDate >= dateRange.start && orderDate <= dateRange.end;
    });

    // Calculate stats - TRUST order.items[] (STEP 5)
    const stats = {
        // Sales - Calculate from items, NOT from order.totalAmount
        totalSales: filteredOrders.reduce((sum, order) => {
            // CRITICAL: Sum from items[], not order.totalAmount
            const orderTotal = order.items?.reduce((itemSum, item) => itemSum + (item.totalPrice || 0), 0) || 0;

            // VALIDATION: Check if order.totalAmount matches calculated total
            if (order.totalAmount !== orderTotal) {
                console.error(`❌ DATA MISMATCH: Order ${order.id}`, {
                    storedTotal: order.totalAmount,
                    calculatedTotal: orderTotal,
                    items: order.items
                });
            }

            return sum + orderTotal;
        }, 0),
        totalOrders: filteredOrders.length,

        // Payment status
        unpaidOrders: filteredOrders.filter(o => o.paymentStatus === 'UNPAID').length,
        dpOrders: filteredOrders.filter(o => o.paymentStatus === 'DP').length,
        paidOrders: filteredOrders.filter(o => o.paymentStatus === 'PAID').length,

        // Production status
        pendingOrders: filteredOrders.filter(o => o.productionStatus === 'PENDING').length,
        inProgressOrders: filteredOrders.filter(o => o.productionStatus === 'IN_PROGRESS').length,
        readyOrders: filteredOrders.filter(o => o.productionStatus === 'READY').length,
        deliveredOrders: filteredOrders.filter(o => o.productionStatus === 'DELIVERED').length,

        // Collection
        totalCollected: filteredOrders.reduce((sum, order) => sum + order.paidAmount, 0),
        totalOutstanding: filteredOrders.reduce((sum, order) => sum + order.remainingAmount, 0),

        // Employees
        totalEmployees: getActiveEmployees().length,
        presentToday: todayAttendances.filter(a => a.checkInTime).length,

        // Average - Calculate from items
        averageOrderValue: filteredOrders.length > 0
            ? filteredOrders.reduce((sum, order) => {
                const orderTotal = order.items?.reduce((itemSum, item) => itemSum + (item.totalPrice || 0), 0) || 0;
                return sum + orderTotal;
            }, 0) / filteredOrders.length
            : 0,
    };

    // Get recent orders (last 5)
    const recentOrders = [...orders]
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
        .slice(0, 5);

    return (
        <div className="owner-dashboard">
            {/* Header */}
            <div className="dashboard-header">
                <div>
                    <h1>📊 Dashboard Owner</h1>
                    <p className="subtitle">Ringkasan bisnis real-time</p>
                </div>

                {/* Period Filter */}
                <div className="period-filter">
                    <button
                        className={`period-btn ${period === 'today' ? 'active' : ''}`}
                        onClick={() => setPeriod('today')}
                    >
                        Hari Ini
                    </button>
                    <button
                        className={`period-btn ${period === 'week' ? 'active' : ''}`}
                        onClick={() => setPeriod('week')}
                    >
                        7 Hari
                    </button>
                    <button
                        className={`period-btn ${period === 'month' ? 'active' : ''}`}
                        onClick={() => setPeriod('month')}
                    >
                        Bulan Ini
                    </button>
                </div>
            </div>

            {/* Stats Grid */}
            <div className="stats-grid">
                {/* Total Sales */}
                <StatsCard
                    icon="💰"
                    title="Total Penjualan"
                    value={formatRupiah(stats.totalSales)}
                    subtitle={`${stats.totalOrders} pesanan`}
                    color="#22c55e"
                />

                {/* Collected */}
                <StatsCard
                    icon="💵"
                    title="Uang Terkumpul"
                    value={formatRupiah(stats.totalCollected)}
                    subtitle={`Piutang: ${formatRupiah(stats.totalOutstanding)}`}
                    color="#3b82f6"
                />

                {/* Pending Orders */}
                <StatsCard
                    icon="⏳"
                    title="Pesanan Pending"
                    value={stats.pendingOrders}
                    subtitle={`Dikerjakan: ${stats.inProgressOrders}`}
                    color="#f59e0b"
                />

                {/* Ready Orders */}
                <StatsCard
                    icon="✅"
                    title="Siap Diambil"
                    value={stats.readyOrders}
                    subtitle={`Terkirim: ${stats.deliveredOrders}`}
                    color="#8b5cf6"
                />
            </div>

            {/* Secondary Stats */}
            <div className="secondary-stats">
                <div className="stat-item">
                    <span className="stat-label">Rata-rata Nilai Order</span>
                    <span className="stat-value">{formatRupiah(stats.averageOrderValue)}</span>
                </div>
                <div className="stat-item">
                    <span className="stat-label">Belum Bayar</span>
                    <span className="stat-value" style={{ color: '#ef4444' }}>{stats.unpaidOrders}</span>
                </div>
                <div className="stat-item">
                    <span className="stat-label">DP</span>
                    <span className="stat-value" style={{ color: '#f59e0b' }}>{stats.dpOrders}</span>
                </div>
                <div className="stat-item">
                    <span className="stat-label">Lunas</span>
                    <span className="stat-value" style={{ color: '#22c55e' }}>{stats.paidOrders}</span>
                </div>
                <div className="stat-item">
                    <span className="stat-label">Karyawan Aktif</span>
                    <span className="stat-value">{stats.totalEmployees}</span>
                </div>
                <div className="stat-item">
                    <span className="stat-label">Hadir Hari Ini</span>
                    <span className="stat-value">{stats.presentToday}/{stats.totalEmployees}</span>
                </div>
            </div>

            {/* Content Grid */}
            <div className="dashboard-content">
                {/* Recent Orders */}
                <div className="content-section">
                    <h2>📋 Pesanan Terbaru</h2>
                    <RecentOrders orders={recentOrders} />
                </div>

                {/* Today Attendance */}
                <div className="content-section">
                    <h2>⏰ Absensi Hari Ini</h2>
                    <TodayAttendance
                        attendances={todayAttendances}
                        employees={getActiveEmployees()}
                    />
                </div>
            </div>
        </div>
    );
}
