/**
 * Order Model
 * Data structure for order/production tracking
 */

export class Order {
    constructor(data = {}) {
        this.id = data.id || null;
        this.transactionId = data.transactionId || null;
        this.customerId = data.customerId || null;
        this.customerName = data.customerName || 'Walk-in Customer';
        this.customerPhone = data.customerPhone || '';

        // Items from transaction
        this.items = data.items || [];
        this.totalAmount = data.totalAmount || 0;

        // Payment tracking
        this.paymentStatus = data.paymentStatus || 'UNPAID'; // UNPAID | DP | PAID
        this.dpAmount = data.dpAmount || 0;
        this.paidAmount = data.paidAmount || 0;
        this.remainingAmount = data.remainingAmount || 0;

        // Production tracking
        this.productionStatus = data.productionStatus || 'PENDING'; // PENDING | IN_PROGRESS | READY | DELIVERED
        this.assignedTo = data.assignedTo || null; // Employee ID
        this.assignedToName = data.assignedToName || ''; // Denormalized

        // Timeline
        this.createdAt = data.createdAt || new Date().toISOString();
        this.estimatedReady = data.estimatedReady || null;
        this.completedAt = data.completedAt || null;
        this.deliveredAt = data.deliveredAt || null;

        // Notes
        this.notes = data.notes || '';
    }

    /**
     * Convert to plain object for storage
     */
    toJSON() {
        const obj = {
            transactionId: this.transactionId,
            customerId: this.customerId,
            customerName: this.customerName,
            customerPhone: this.customerPhone,
            items: this.items,
            totalAmount: this.totalAmount,
            paymentStatus: this.paymentStatus,
            dpAmount: this.dpAmount,
            paidAmount: this.paidAmount,
            remainingAmount: this.remainingAmount,
            productionStatus: this.productionStatus,
            assignedTo: this.assignedTo,
            assignedToName: this.assignedToName,
            createdAt: this.createdAt,
            estimatedReady: this.estimatedReady,
            completedAt: this.completedAt,
            deliveredAt: this.deliveredAt,
            notes: this.notes,
        };

        // Only include id if it exists (for updates, not for inserts)
        if (this.id !== null && this.id !== undefined) {
            obj.id = this.id;
        }

        return obj;
    }

    /**
     * Create from database record
     */
    static fromDB(record) {
        return new Order(record);
    }

    /**
     * Update payment status based on amounts
     */
    updatePaymentStatus() {
        if (this.paidAmount >= this.totalAmount) {
            this.paymentStatus = 'PAID';
            this.remainingAmount = 0;
        } else if (this.paidAmount > 0) {
            this.paymentStatus = 'DP';
            this.remainingAmount = this.totalAmount - this.paidAmount;
        } else {
            this.paymentStatus = 'UNPAID';
            this.remainingAmount = this.totalAmount;
        }
    }

    /**
     * Add payment
     */
    addPayment(amount) {
        this.paidAmount += amount;
        if (this.paidAmount === amount && amount < this.totalAmount) {
            this.dpAmount = amount;
        }
        this.updatePaymentStatus();
    }

    /**
     * Check if order is completed
     */
    isCompleted() {
        return this.productionStatus === 'DELIVERED';
    }

    /**
     * Check if payment is complete
     */
    isFullyPaid() {
        return this.paymentStatus === 'PAID';
    }
}
