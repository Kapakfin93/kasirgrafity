/**
 * IndexedDB Schema using Dexie
 * Local-first database for offline capability
 */

import Dexie from 'dexie';

export const db = new Dexie('JogloPOSDatabase');

// Define database schema
db.version(1).stores({
    // Transactions
    transactions: '++id, timestamp, cashierId, totalAmount, paymentMode, status',

    // Transaction Items (for detailed reporting)
    transactionItems: '++id, transactionId, productId, categoryId, qty, price',

    // Orders (production tracking)
    orders: '++id, transactionId, customerId, paymentStatus, productionStatus, createdAt, estimatedReady',

    // Employees
    employees: '++id, name, role, shift, status, createdAt',

    // Attendance
    attendance: '++id, employeeId, date, shift, status, checkInTime, checkOutTime',

    // Customers (optional, for future)
    customers: '++id, name, phone, address, createdAt',

    // Settings
    settings: 'key, value',
});

// Helper functions for common queries

/**
 * Get transactions by date range
 */
export const getTransactionsByDateRange = async (startDate, endDate) => {
    return await db.transactions
        .where('timestamp')
        .between(startDate, endDate, true, true)
        .toArray();
};

/**
 * Get today's transactions
 */
export const getTodayTransactions = async () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    return await getTransactionsByDateRange(today, tomorrow);
};

/**
 * Get active employees
 */
export const getActiveEmployees = async () => {
    return await db.employees
        .where('status')
        .equals('ACTIVE')
        .toArray();
};

/**
 * Get attendance by employee and date
 */
export const getAttendanceByEmployeeAndDate = async (employeeId, date) => {
    const dateStr = date.toISOString().split('T')[0];
    return await db.attendance
        .where(['employeeId', 'date'])
        .equals([employeeId, dateStr])
        .first();
};

/**
 * Get orders by status
 */
export const getOrdersByStatus = async (status) => {
    return await db.orders
        .where('productionStatus')
        .equals(status)
        .toArray();
};

/**
 * Get orders by payment status
 */
export const getOrdersByPaymentStatus = async (paymentStatus) => {
    return await db.orders
        .where('paymentStatus')
        .equals(paymentStatus)
        .toArray();
};

/**
 * Initialize default settings
 */
export const initializeDefaultSettings = async () => {
    const existingSettings = await db.settings.count();

    if (existingSettings === 0) {
        await db.settings.bulkAdd([
            { key: 'owner_pin', value: '1234' },
            { key: 'store_name', value: 'JOGLO PRINTING' },
            { key: 'store_address', value: 'Jl. Diponegoro, Rw. 4, Jogoloyo' },
            { key: 'store_city', value: 'Demak, Jawa Tengah' },
            { key: 'store_phone', value: '0813-9028-6826' },
            { key: 'auto_print', value: 'false' },
            { key: 'default_printer', value: 'thermal' },
        ]);
    }
};

/**
 * Get setting value
 */
export const getSetting = async (key) => {
    const setting = await db.settings.get(key);
    return setting?.value;
};

/**
 * Update setting value
 */
export const updateSetting = async (key, value) => {
    await db.settings.put({ key, value });
};

// Initialize database on import
initializeDefaultSettings().catch(console.error);

export default db;
