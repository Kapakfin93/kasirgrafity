import categories from './categories';
import products from './products';
import finishings from './finishings';

export {
    categories,
    products,
    finishings
};
