/**
 * useTransaction Hook - REFACTORED
 * Temporary UI workspace for configuring items before adding to order
 * 
 * ARCHITECTURE:
 * - This hook manages TEMPORARY state only (during item configuration)
 * - Once payment confirmed → data moves to OrderStore (single source of truth)
 * - No business logic here - delegates to core calculators
 */

import { useState } from 'react';
import { v4 as uuid } from 'uuid';
import { MASTER_DATA } from '../data/initialData';
import {
    calculateAreaPrice,
    calculateLinearPrice,
    calculateMatrixPrice,
    calculateUnitSheetPrice,
    calculateUnitPrice,
    calculateManualPrice
} from '../core/calculators';
import { validateTransactionInput } from '../core/validators';
import { buildItemDescription, extractFinishingNames } from '../core/descriptionBuilder';

const INITIAL_INPUT_STATE = {
    product: null,
    qty: 1,
    length: '',
    width: '',
    sizeKey: null,
    manualPrice: '',
    selectedFinishings: []
};

const INITIAL_PAYMENT_STATE = {
    mode: 'TUNAI',
    amountPaid: '',
    isLocked: false,
    showNotaPreview: false
};

// Transaction Stage Enum
export const TRANSACTION_STAGES = {
    CART: 'CART',
    AWAITING_PAYMENT: 'AWAITING_PAYMENT',
    POST_PAYMENT: 'POST_PAYMENT'
};

export function useTransaction() {
    // TEMPORARY WORKSPACE STATE
    const [currentCategory, setCurrentCategory] = useState(MASTER_DATA.categories[0]);
    const [configuratorInput, setConfiguratorInput] = useState(INITIAL_INPUT_STATE);
    const [tempItems, setTempItems] = useState([]); // Temporary cart items
    const [paymentState, setPaymentState] = useState(INITIAL_PAYMENT_STATE);
    const [transactionStage, setTransactionStage] = useState(TRANSACTION_STAGES.CART);

    // === CATEGORY ACTIONS ===
    const selectCategory = (categoryId) => {
        const cat = MASTER_DATA.categories.find(c => c.id === categoryId);
        if (cat) {
            setCurrentCategory(cat);
            setConfiguratorInput(INITIAL_INPUT_STATE);
        }
    };

    /**
     * buildCartItem - SINGLE GATEKEEPER FOR ALL ITEMS
     * STRICT CONTRACT ENFORCEMENT - NO FALLBACKS ALLOWED
     * 
     * This is the ONLY function that can create valid cart items.
     * ALL configurators MUST send raw data here.
     * 
     * @param {Object} rawInput - Raw data from configurator
     * @param {Object} rawInput.product - Product object from MASTER_DATA (REQUIRED)
     * @param {number} rawInput.qty - Quantity (REQUIRED, >= 1)
     * @param {Object} rawInput.dimensions - Dimensions based on pricingType
     * @param {Array} rawInput.finishings - Selected finishing objects
     * @param {number} rawInput.manualPrice - Manual price (only for MANUAL type)
     * @returns {Object} Validated CartItem
     * @throws {Error} If any required field is missing or invalid
     */
    // ===== STRICT CONTRACT BUILDER =====
    const buildCartItem = (rawInput) => {
        console.log('🔨 buildCartItem called with:', rawInput);

        const { product, qty, dimensions = {}, finishings = [], manualPrice } = rawInput;

        // Helper: Calculate total finishing cost from finishings array
        const calculateFinishingCost = (finishings) => {
            if (!finishings || finishings.length === 0) return 0;
            return finishings.reduce((total, f) => total + (f.price || 0), 0);
        };

        // 1. Validate product data (MUST exist)
        if (!product || !product.id || !product.name) {
            throw new Error('CART ITEM REJECTED: Product data tidak valid');
        }

        // 2. Validate qty (MUST be > 0)
        if (!qty || qty <= 0 || isNaN(qty)) {
            throw new Error(`CART ITEM REJECTED: Quantity harus > 0 (${qty})`);
        }

        // Detect pricingType from current category
        const pricingType = currentCategory?.logic_type || 'MANUAL';

        // ===== CALCULATE PRICE (using core calculators) =====
        let calculatedPrice = 0;
        let unitPrice = 0;

        try {
            switch (pricingType) {
                case 'AREA':
                    const areaResult = calculateAreaPrice(
                        product.price || 0,
                        dimensions.length || 0,
                        dimensions.width || 0,
                        qty,
                        finishings
                    );
                    calculatedPrice = areaResult.subtotal;
                    unitPrice = areaResult.unitPrice;
                    break;

                case 'LINEAR':
                    const linearResult = calculateLinearPrice(
                        product.price || 0,
                        dimensions.length || 0,
                        qty,
                        finishings
                    );
                    calculatedPrice = linearResult.subtotal;
                    unitPrice = linearResult.unitPrice;
                    break;

                case 'MATRIX':
                    // MATRIX pricing for Poster/Size-based products
                    const { sizeKey, printType, material } = dimensions;
                    const priceMatrix = product.priceMatrix;

                    // Validate matrix data exists
                    if (!priceMatrix) {
                        throw new Error(`CART ITEM REJECTED: Product ${product.name} tidak memiliki priceMatrix`);
                    }

                    if (!sizeKey || !printType || !material) {
                        throw new Error(`CART ITEM REJECTED: MATRIX product memerlukan sizeKey, printType, material`);
                    }

                    // Build nested matrix path: priceMatrix[printType][material]
                    let nestedMatrix;
                    try {
                        nestedMatrix = priceMatrix[printType][material];
                    } catch (lookupError) {
                        throw new Error(`CART ITEM REJECTED: Matrix path tidak valid - ${printType}/${material}`);
                    }

                    if (!nestedMatrix || typeof nestedMatrix !== 'object') {
                        throw new Error(`CART ITEM REJECTED: Matrix tidak ditemukan untuk ${printType}/${material}`);
                    }

                    // Now call calculateMatrixPrice with correct signature: (sizeKey, priceMatrix, qty)
                    const matrixResult = calculateMatrixPrice(
                        sizeKey,           // 'A2', 'A3', etc
                        nestedMatrix,      // { A2: 15000, A3: 25000, ... }
                        qty
                    );

                    if (!matrixResult.subtotal || matrixResult.subtotal <= 0) {
                        throw new Error(`CART ITEM REJECTED: Harga tidak ditemukan untuk ${sizeKey}`);
                    }

                    calculatedPrice = matrixResult.subtotal;
                    unitPrice = matrixResult.subtotal / qty; // Calculate unit price from total
                    break;

                case 'UNIT':
                    // UNIT pricing for Merchandise/Office
                    const finishingCost = calculateFinishingCost(finishings);
                    const unitResult = calculateUnitPrice(
                        product.price || 0,  // basePrice
                        finishingCost,        // total finishing cost
                        qty
                    );

                    if (!unitResult.subtotal || unitResult.subtotal <= 0) {
                        throw new Error(`CART ITEM REJECTED: Harga tidak valid untuk ${product.name}`);
                    }

                    calculatedPrice = unitResult.subtotal;
                    unitPrice = unitResult.subtotal / qty; // Calculate unit price from total
                    break;

                case 'UNIT_SHEET':
                    // UNIT_SHEET pricing for A3+ products
                    const cuttingCost = dimensions?.cuttingCost || 0;
                    const sheetFinishingCost = calculateFinishingCost(finishings);

                    const sheetResult = calculateUnitSheetPrice(
                        product.price || 0,  // basePrice
                        cuttingCost,          // cutting cost
                        sheetFinishingCost,   // finishing cost
                        qty
                    );

                    if (!sheetResult.subtotal || sheetResult.subtotal <= 0) {
                        throw new Error(`CART ITEM REJECTED: Harga tidak valid untuk ${product.name}`);
                    }

                    calculatedPrice = sheetResult.subtotal;
                    unitPrice = sheetResult.subtotal / qty; // Calculate unit price from total
                    break;

                case 'MANUAL':
                    const manualResult = calculateManualPrice(manualPrice || 0, qty);
                    calculatedPrice = manualResult.subtotal;
                    unitPrice = manualResult.unitPrice;
                    break;

                default:
                    throw new Error(`CART ITEM REJECTED: Pricing type tidak dikenali (${pricingType})`);
            }
        } catch (calcError) {
            throw new Error(`CART ITEM REJECTED: Error kalkulasi harga - ${calcError.message}`);
        }

        // 5. Validate calculated price (MUST be > 0, NO zero-price items in final cart)
        if (typeof calculatedPrice !== 'number' || isNaN(calculatedPrice)) {
            throw new Error(`CART ITEM REJECTED: Harga hasil kalkulasi NaN (${product.name})`);
        }

        if (calculatedPrice <= 0) {
            throw new Error(`CART ITEM REJECTED: Harga harus > 0 (${product.name}: Rp ${calculatedPrice})`);
        }

        // ===== BUILD DESCRIPTION (using core builder) =====
        const finishingNames = extractFinishingNames(finishings);
        let description = '';

        try {
            description = buildItemDescription({
                productName: product.name,
                pricingType: pricingType,
                specs: dimensions,
                finishingNames: finishingNames
            });
        } catch (descError) {
            throw new Error(`CART ITEM REJECTED: Error membuat deskripsi - ${descError.message}`);
        }

        // 6. Validate description (MUST contain product name)
        if (!description || !description.includes(product.name)) {
            throw new Error(`CART ITEM REJECTED: Deskripsi tidak valid (${description})`);
        }

        // ===== BUILD VALIDATED CART ITEM =====
        const cartItem = {
            id: uuid(),
            productId: product.id,
            name: product.name,
            description: description,
            pricingType: pricingType,
            qty: qty,
            dimensions: dimensions,
            finishings: finishings.map(f => ({
                id: f.id,
                name: f.name,
                price: f.price || 0
            })),
            unitPrice: unitPrice,
            totalPrice: calculatedPrice
        };

        console.log("✅ Cart item built successfully:", cartItem);
        return cartItem;
    };
    // === CONFIGURATOR ACTIONS ===
    const updateConfiguratorInput = (updates) => {
        setConfiguratorInput(prev => ({ ...prev, ...updates }));
    };

    // === PRICE CALCULATION (delegated to core) ===
    const _calculateCurrentPrice = () => {
        const { product, qty, length, width, sizeKey, manualPrice, selectedFinishings } = configuratorInput;
        const logic_type = currentCategory?.logic_type;

        // Rule #3: FAIL-SAFE. Return 0, not NaN.
        if (!currentCategory) return { subtotal: 0, breakdown: '' };
        if (!product && logic_type !== 'MANUAL') return { subtotal: 0, breakdown: '' };

        // Calculate finishing cost
        const finishingCost = (selectedFinishings || []).reduce((sum, f) => sum + (f.price || 0), 0);

        let result = { subtotal: 0, breakdown: '' };

        try {
            // Delegate to core calculators
            switch (logic_type) {
                case 'AREA':
                    if (length && width && product?.price) {
                        result = calculateAreaPrice(parseFloat(length), parseFloat(width), product.price, qty);
                        result.subtotal += (finishingCost * qty);
                    }
                    break;

                case 'LINEAR':
                    if (length && product?.price) {
                        result = calculateLinearPrice(parseFloat(length), product.price, qty);
                        result.subtotal += (finishingCost * qty);
                    }
                    break;

                case 'MATRIX':
                    if (sizeKey && product?.prices) {
                        result = calculateMatrixPrice(sizeKey, product.prices, qty);
                        result.subtotal += (finishingCost * qty);
                    }
                    break;

                case 'UNIT_SHEET':
                    if (product?.price) {
                        result = calculateUnitSheetPrice(product.price, 0, finishingCost, qty);
                    }
                    break;

                case 'UNIT':
                    if (product?.price) {
                        result = calculateUnitPrice(product.price, finishingCost, qty);
                    }
                    break;

                case 'MANUAL':
                    const price = parseFloat(manualPrice) || 0;
                    result = calculateManualPrice(price, qty);
                    break;
            }
        } catch (e) {
            console.error("Calculation Error:", e);
            return { subtotal: 0, breakdown: 'Error' };
        }

        return {
            subtotal: isNaN(result.subtotal) ? 0 : Math.floor(result.subtotal),
            breakdown: result.breakdown
        };
    };

    // === CART ACTIONS ===
    /**
     * addItemToCart - ENFORCES ALL ITEMS GO THROUGH buildCartItem
     * 
     * Accepts EITHER:
     * 1. preConfiguredItem (from modern configurators like Poster/Textile)
     * 2. null (uses configuratorInput for legacy flow)
     * 
     * BOTH paths MUST call buildCartItem() - NO EXCEPTIONS
     */
    const addItemToCart = (preConfiguredItem = null) => {
        console.log("=== addItemToCart called ===");
        console.log("preConfiguredItem:", preConfiguredItem);

        try {
            let rawInput;

            if (preConfiguredItem) {
                // MODERN CONFIGURATOR PATH
                // IMPORTANT: Handle BOTH old and new structures

                // Check if it's NEW structure (has 'product' object directly)
                if (preConfiguredItem.product && typeof preConfiguredItem.product === 'object') {
                    // NEW: Direct product object from refactored configurators
                    rawInput = {
                        product: preConfiguredItem.product,
                        qty: preConfiguredItem.qty || 1,
                        dimensions: preConfiguredItem.dimensions || {},
                        finishings: preConfiguredItem.finishings || [],
                        manualPrice: preConfiguredItem.manualPrice
                    };
                } else {
                    // OLD: productId/productName structure from un-refactored configurators
                    rawInput = {
                        product: {
                            id: preConfiguredItem.productId,
                            name: preConfiguredItem.productName,
                            price: preConfiguredItem.basePrice || preConfiguredItem.unitPrice || 0
                        },
                        qty: preConfiguredItem.quantity || preConfiguredItem.qty || 1,
                        dimensions: preConfiguredItem.specs || preConfiguredItem.dimensions || {},
                        finishings: preConfiguredItem.finishings || [],
                        manualPrice: preConfiguredItem.priceInput
                    };
                }
            } else {
                // LEGACY CONFIGURATOR PATH (uses configuratorInput)
                rawInput = {
                    product: configuratorInput.product,
                    qty: configuratorInput.qty,
                    dimensions: {
                        length: configuratorInput.length,
                        width: configuratorInput.width,
                        sizeKey: configuratorInput.sizeKey
                    },
                    finishings: configuratorInput.selectedFinishings || [],
                    manualPrice: configuratorInput.manualPrice
                };
            }

            console.log("Mapped rawInput for buildCartItem:", rawInput);

            // === CRITICAL: ALL ITEMS MUST GO THROUGH buildCartItem ===
            const validatedItem = buildCartItem(rawInput);

            // Add to cart
            setTempItems(prev => [...prev, validatedItem]);
            setConfiguratorInput(INITIAL_INPUT_STATE);

            console.log("✅ Item added to cart");

        } catch (error) {
            console.error("❌ Add to Cart Failed:", error);
            alert(`GAGAL TAMBAH ITEM:\n${error.message}`);
        }
    };

    const removeItem = (id) => {
        setTempItems(prev => prev.filter(item => item.id !== id));
    };

    const clearCart = () => {
        setTempItems([]);
        setConfiguratorInput(INITIAL_INPUT_STATE);
    };

    // === CALCULATION ===
    const calculateTotal = () => {
        // Standardized: Total uses 'totalPrice' field
        return tempItems.reduce((sum, item) => sum + (item.totalPrice || 0), 0);
    };

    // === PAYMENT ACTIONS ===
    const updatePaymentState = (updates) => {
        setPaymentState(prev => ({ ...prev, ...updates }));
    };

    /**
     * Validate stage transition from CART to AWAITING_PAYMENT
     * Rule: Items with totalPrice === 0 block transition
     */
    const validateStageTransition = () => {
        // Check for zero-price items
        const zeroItems = tempItems.filter(item => item.totalPrice === 0);
        if (zeroItems.length > 0) {
            const itemNames = zeroItems.map(i => i.productName).join(', ');
            throw new Error(`Item dengan harga 0 tidak boleh diproses: ${itemNames}`);
        }

        // Check cart not empty
        if (tempItems.length === 0) {
            throw new Error('Keranjang kosong');
        }

        return true;
    };

    const confirmPayment = () => {
        const total = calculateTotal();
        const paid = parseFloat(paymentState.amountPaid) || 0;

        if (paymentState.mode === 'TUNAI' && paid < total) {
            alert('Pembayaran Kurang!');
            return false;
        }

        // Lock the transaction
        setPaymentState(prev => ({ ...prev, isLocked: true }));
        return true;
    };

    /**
     * assertValidCartItem - Validate individual cart item
     * @throws {Error} If item violates contract
     */
    const assertValidCartItem = (item, index) => {
        if (!item.name || item.name.trim() === '') {
            throw new Error(`ORDER REJECTED: Item #${index + 1} tidak memiliki nama`);
        }

        if (!item.description || item.description.trim() === '') {
            throw new Error(`ORDER REJECTED: Item #${index + 1} "${item.name}" tidak memiliki deskripsi`);
        }

        if (typeof item.totalPrice !== 'number' || isNaN(item.totalPrice)) {
            throw new Error(`ORDER REJECTED: Item #${index + 1} "${item.name}" memiliki harga invalid (NaN)`);
        }

        if (item.totalPrice <= 0) {
            throw new Error(`ORDER REJECTED: Item #${index + 1} "${item.name}" memiliki harga ${item.totalPrice} (harus > 0)`);
        }
    };

    /**
     * finalizeOrder (Rule #1)
     * Collects and hands over data to useOrderStore.createOrder
     * Does NOT touch database directly.
     * 
     * STRICT VALIDATION: Block empty or invalid orders
     */
    const finalizeOrder = async (createOrderFn) => {
        console.log("=== finalizeOrder called ===");

        // ===== CRITICAL VALIDATION: BLOCK INVALID ORDERS =====

        // 1. Check for empty cart
        if (!tempItems || tempItems.length === 0) {
            throw new Error("ORDER REJECTED: Tidak ada item dalam keranjang");
        }

        console.log(`Validating ${tempItems.length} items...`);

        // 2. Validate EVERY item
        try {
            tempItems.forEach((item, index) => {
                assertValidCartItem(item, index);
            });
            console.log("✅ All items passed validation");
        } catch (validationError) {
            console.error("❌ Item validation failed:", validationError);
            throw validationError; // Re-throw to stop order creation
        }

        // 3. Calculate totals
        const total = calculateTotal();
        const paid = parseFloat(paymentState.amountPaid) || 0;

        const orderData = {
            items: tempItems,
            totalAmount: total,
            paidAmount: paid,
            paymentStatus: paid >= total ? 'PAID' : (paid > 0 ? 'DP' : 'UNPAID'),
            remainingAmount: Math.max(0, total - paid),
            createdAt: new Date().toISOString(),
            notes: ''
        };

        console.log("Order data prepared:", orderData);

        try {
            console.log("Calling createOrderFn...");
            const order = await createOrderFn(orderData);
            console.log("createOrderFn returned:", order);
            console.log("Order ID:", order?.id);

            if (!order) {
                throw new Error("createOrderFn returned null/undefined");
            }

            console.log("✅ Returning order:", order);
            return order;
        } catch (error) {
            console.error("❌ Order Finalization Failed:", error);
            throw error;
        }
    };

    // === RESET TRANSACTION ===
    const resetTransaction = () => {
        setTempItems([]);
        setConfiguratorInput(INITIAL_INPUT_STATE);
        setPaymentState(INITIAL_PAYMENT_STATE);
        setTransactionStage(TRANSACTION_STAGES.CART);
    };

    // === RETURN API ===
    return {
        // Category
        currentCategory,
        selectCategory,

        // Configurator (temporary workspace)
        configuratorInput,
        updateConfiguratorInput,
        getCurrentPreview: _calculateCurrentPrice,

        // Temporary cart
        items: tempItems,
        addItemToCart,
        removeItem,
        clearCart,
        calculateTotal,

        // Payment (temporary until confirmed)
        paymentState,
        updatePaymentState,
        confirmPayment,
        finalizeOrder, // New Action

        // Transaction Stage
        transactionStage,
        setTransactionStage,
        validateStageTransition,

        // Reset
        resetTransaction,
    };
}
