const categories = [
    { id: 'POSTER', name: 'Poster' },
    { id: 'BANNER', name: 'Banner / Spanduk' },
    { id: 'STIKER', name: 'Stiker' }
];

export default categories;
