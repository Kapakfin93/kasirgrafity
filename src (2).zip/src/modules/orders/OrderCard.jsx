/**
 * OrderCard Component
 * Individual order card with status update capabilities
 */

import React, { useState } from 'react';
import { useOrderStore } from '../../stores/useOrderStore';
import { usePermissions } from '../../hooks/usePermissions';
import { ORDER_STATUS, PAYMENT_STATUS } from '../../core/constants';
import { formatRupiah } from '../../core/formatters';
import { formatDateTime, formatDate } from '../../utils/dateHelpers';

export function OrderCard({ order }) {
    const { updateProductionStatus, updateOrder } = useOrderStore();
    const { canUpdateOrderStatus } = usePermissions();
    const [isExpanded, setIsExpanded] = useState(false);
    const [updating, setUpdating] = useState(false);

    const statusConfig = ORDER_STATUS[order.productionStatus];
    const paymentConfig = PAYMENT_STATUS[order.paymentStatus];

    // Handle status change
    const handleStatusChange = async (newStatus) => {
        if (!canUpdateOrderStatus) {
            alert('Anda tidak memiliki izin untuk mengubah status');
            return;
        }

        if (window.confirm(`Ubah status menjadi "${ORDER_STATUS[newStatus].label}"?`)) {
            setUpdating(true);
            try {
                await updateProductionStatus(order.id, newStatus);
                alert('✅ Status berhasil diupdate!');
            } catch (error) {
                alert('❌ Gagal update status: ' + error.message);
            }
            setUpdating(false);
        }
    };

    // Determine available next actions
    const getNextActions = () => {
        const actions = [];

        switch (order.productionStatus) {
            case 'PENDING':
                actions.push({ status: 'IN_PROGRESS', label: '🔨 Mulai Kerjakan', color: '#3b82f6' });
                break;
            case 'IN_PROGRESS':
                actions.push({ status: 'READY', label: '✅ Tandai Selesai', color: '#22c55e' });
                break;
            case 'READY':
                actions.push({ status: 'DELIVERED', label: '📦 Serahkan ke Customer', color: '#64748b' });
                break;
        }

        return actions;
    };

    const nextActions = getNextActions();

    return (
        <div className={`order-card status-${order.productionStatus.toLowerCase()}`}>
            {/* Card Header */}
            <div className="order-card-header">
                <div className="order-id">
                    <span className="id-label">#{order.id}</span>
                    <span className="tx-id">{order.transactionId}</span>
                </div>
                <div className="order-badges">
                    <span
                        className="status-badge production"
                        style={{ backgroundColor: statusConfig.color }}
                    >
                        {statusConfig.label}
                    </span>
                    <span
                        className="status-badge payment"
                        style={{ backgroundColor: paymentConfig.color }}
                    >
                        {paymentConfig.label}
                    </span>
                </div>
            </div>

            {/* Customer Info */}
            <div className="order-customer">
                <strong>👤 {order.customerName}</strong>
                {order.customerPhone && <span className="phone">📞 {order.customerPhone}</span>}
            </div>

            {/* Items Summary */}
            <div className="order-items-summary">
                <span className="items-count">{order.items.length} item(s)</span>
                <button
                    className="toggle-details-btn"
                    onClick={() => setIsExpanded(!isExpanded)}
                >
                    {isExpanded ? '▲ Sembunyikan Detail' : '▼ Lihat Detail'}
                </button>
            </div>

            {/* Expanded Items */}
            {isExpanded && (
                <div className="order-items-detail">
                    {order.items.map((item, idx) => (
                        <div key={idx} className="order-item" style={{ padding: '8px 0', borderBottom: idx < order.items.length - 1 ? '1px dashed #e2e8f0' : 'none' }}>
                            <div className="item-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                                <div className="item-name" style={{ fontWeight: '600' }}>{item.productName}</div>
                                <div className="item-qty">x{item.qty}</div>
                            </div>
                            <div className="item-desc" style={{ fontSize: '12px', color: '#64748b', marginTop: '2px' }}>
                                {item.description}
                            </div>
                            {item.finishings && item.finishings.length > 0 && (
                                <div className="item-finishings" style={{ display: 'flex', flexWrap: 'wrap', gap: '4px', marginTop: '4px' }}>
                                    {item.finishings.map((f, i) => (
                                        <span key={i} className="finishing-tag" style={{
                                            fontSize: '10px', background: '#f0fdf4', color: '#16a34a',
                                            padding: '1px 6px', borderRadius: '4px', border: '1px solid #bbf7d0'
                                        }}>
                                            + {typeof f === 'string' ? f : f.name}
                                        </span>
                                    ))}
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            )}

            {/* Payment Info */}
            <div className="order-payment-info">
                <div className="payment-row">
                    <span>Total:</span>
                    <strong>{formatRupiah(order.totalAmount)}</strong>
                </div>
                {order.paymentStatus === 'DP' && (
                    <>
                        <div className="payment-row small">
                            <span>Dibayar:</span>
                            <span>{formatRupiah(order.paidAmount)}</span>
                        </div>
                        <div className="payment-row small remaining">
                            <span>Sisa:</span>
                            <strong>{formatRupiah(order.remainingAmount)}</strong>
                        </div>
                    </>
                )}
            </div>

            {/* Timeline */}
            <div className="order-timeline">
                <div className="timeline-item">
                    <span className="timeline-label">📅 Dipesan:</span>
                    <span>{formatDateTime(order.createdAt)}</span>
                </div>
                {order.estimatedReady && (
                    <div className="timeline-item">
                        <span className="timeline-label">⏰ Estimasi Selesai:</span>
                        <span>{formatDateTime(order.estimatedReady)}</span>
                    </div>
                )}
                {order.completedAt && (
                    <div className="timeline-item">
                        <span className="timeline-label">✅ Selesai:</span>
                        <span>{formatDateTime(order.completedAt)}</span>
                    </div>
                )}
            </div>

            {/* Assigned To */}
            {order.assignedToName && (
                <div className="order-assigned">
                    <span>👷 Dikerjakan: <strong>{order.assignedToName}</strong></span>
                </div>
            )}

            {/* Notes */}
            {order.notes && (
                <div className="order-notes">
                    <strong>📝 Catatan:</strong>
                    <p>{order.notes}</p>
                </div>
            )}

            {/* Action Buttons */}
            {nextActions.length > 0 && canUpdateOrderStatus && (
                <div className="order-actions">
                    {nextActions.map((action, idx) => (
                        <button
                            key={idx}
                            className="action-btn"
                            style={{ backgroundColor: action.color }}
                            onClick={() => handleStatusChange(action.status)}
                            disabled={updating}
                        >
                            {updating ? '⏳ Memproses...' : action.label}
                        </button>
                    ))}
                </div>
            )}
        </div>
    );
}
