import React from 'react';
import { formatRupiah } from '../../core/formatters';

export function NotaPreview({ items, totalAmount, paymentState, onClose, onPrint }) {
    const { mode, amountPaid } = paymentState || {};
    const paid = parseFloat(amountPaid) || 0;
    const change = Math.max(0, paid - totalAmount);
    const isTunai = mode === 'TUNAI';

    // Get current date/time
    const now = new Date();
    const dateStr = now.toLocaleDateString('id-ID', {
        day: '2-digit',
        month: 'long',
        year: 'numeric'
    });
    const timeStr = now.toLocaleTimeString('id-ID', {
        hour: '2-digit',
        minute: '2-digit'
    });

    return (
        <div className="nota-preview-overlay" onClick={onClose}>
            <div className="nota-preview-container" onClick={e => e.stopPropagation()}>
                {/* Close Button */}
                <button className="nota-close-btn" onClick={onClose}>✕</button>

                {/* Nota Content */}
                <div className="nota-content">
                    {/* Header */}
                    <div className="nota-header">
                        <h1>JOGLO PRINTING</h1>
                        <p>Jl. Diponegoro, Rw. 4, Jogoloyo</p>
                        <p>Demak, Jawa Tengah</p>
                        <p>Telp: 0813-9028-6826</p>
                        <p className="nota-highlight">BUKA 24 JAM</p>
                    </div>

                    <div className="nota-divider">================================</div>

                    <div className="nota-datetime">
                        <span>{dateStr}</span>
                        <span>{timeStr}</span>
                    </div>

                    <div className="nota-divider">================================</div>

                    {/* Items */}
                    <div className="nota-items">
                        {items.map((item, index) => {
                            // KOREKSI: finishings adalah sibling dari dimensions, bukan nested
                            const { productName, dimensions, logic_type, qty, finalPrice, finishings } = item;
                            const { length, width, sizeKey } = dimensions || {};
                            const unitPrice = finalPrice / qty;

                            return (
                                <div key={item.id} className="nota-item">
                                    <div className="nota-item-name">
                                        {index + 1}. {productName}
                                    </div>

                                    <div className="nota-item-details">
                                        {logic_type === 'AREA' && <span>Ukuran: {length}m × {width}m</span>}
                                        {logic_type === 'LINEAR' && <span>Panjang: {length}m</span>}
                                        {logic_type === 'MATRIX' && <span>Ukuran: {sizeKey}</span>}
                                        {logic_type === 'UNIT' && <span>Satuan</span>}
                                        {logic_type === 'UNIT_SHEET' && <span>Per Lembar</span>}
                                    </div>

                                    {finishings && finishings.length > 0 && (
                                        <div className="nota-item-finishing">
                                            {finishings.map((f, idx) => (
                                                <div key={idx}>+ {f.name}</div>
                                            ))}
                                        </div>
                                    )}

                                    <div className="nota-item-price-row">
                                        <span>{qty} × {formatRupiah(unitPrice)}</span>
                                        <span className="nota-item-total">{formatRupiah(finalPrice)}</span>
                                    </div>
                                </div>
                            );
                        })}
                    </div>

                    <div className="nota-divider">================================</div>

                    {/* Summary */}
                    <div className="nota-summary">
                        <div className="nota-total-row">
                            <span>TOTAL</span>
                            <span>{formatRupiah(totalAmount)}</span>
                        </div>

                        {isTunai && (
                            <>
                                <div className="nota-row">
                                    <span>DIBAYAR</span>
                                    <span>{formatRupiah(paid)}</span>
                                </div>
                                <div className="nota-row">
                                    <span>KEMBALI</span>
                                    <span>{formatRupiah(change)}</span>
                                </div>
                            </>
                        )}
                    </div>

                    <div className="nota-divider">================================</div>

                    <div className="nota-status">
                        LUNAS - {mode}
                    </div>

                    <div className="nota-divider">================================</div>

                    {/* Footer */}
                    <div className="nota-footer">
                        <p>Terima Kasih</p>
                        <p>Silakan Datang Kembali</p>
                    </div>
                </div>

                {/* Action Buttons */}
                <div className="nota-actions">
                    <button className="btn-nota-print" onClick={onPrint}>
                        🖨️ PRINT NOTA
                    </button>
                    <button className="btn-nota-close" onClick={onClose}>
                        TUTUP
                    </button>
                </div>
            </div>
        </div>
    );
}
