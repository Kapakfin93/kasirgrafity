import React from 'react';
import { MASTER_DATA } from '../../data/initialData';

export function Sidebar({ selectedCategoryId, onSelectCategory }) {
    // Grouping Logic
    const MAIN_GROUPS = [
        { id: 'BANNER_GROUP', label: 'Banner', icon: '🚩', subIds: ['BANNER'] },
        { id: 'POSTER_GROUP', label: 'Poster', icon: '🖼️', subIds: ['POSTER'] },
        { id: 'STIKER_GROUP', label: 'Stiker & A3', icon: '🖨️', subIds: ['A3PLUS'] },
        { id: 'TEXTILE_GROUP', label: 'Textile', icon: '👕', subIds: ['TEXTILE'] },
        { id: 'OTHERS_GROUP', label: 'Lainnya', icon: '📦', subIds: ['MERCH', 'OFFICE', 'CUSTOM'] }
    ];

    // Find active group based on selectedCategoryId
    const activeGroup = MAIN_GROUPS.find(g => g.subIds.includes(selectedCategoryId)) || MAIN_GROUPS[0];

    return (
        <aside className="sidebar-nav">
            <div className="nav-header">
                <h2>KATEGORI</h2>
            </div>

            {/* Level 1: Main Groups */}
            <div className="main-group-grid">
                {MAIN_GROUPS.map(group => (
                    <button
                        key={group.id}
                        className={`main-group-btn ${activeGroup.id === group.id ? 'active' : ''}`}
                        onClick={() => onSelectCategory(group.subIds[0])} // Default to first sub
                    >
                        <span className="group-icon">{group.icon}</span>
                        <span className="group-label">{group.label}</span>
                    </button>
                ))}
            </div>

            {/* Level 2: Sub Categories */}
            <div className="sub-category-list">
                <div className="sub-header">Sub Kategori</div>
                {activeGroup.subIds.map(subId => {
                    const cat = MASTER_DATA.categories.find(c => c.id === subId);
                    if (!cat) return null;
                    return (
                        <button
                            key={cat.id}
                            className={`nav-item ${selectedCategoryId === cat.id ? 'active' : ''}`}
                            onClick={() => onSelectCategory(cat.id)}
                        >
                            {cat.name}
                        </button>
                    );
                })}
            </div>
        </aside>
    );
}
