import React from 'react';
import { ProductGrid } from './shared/ProductGrid';
import { ActionBar } from './shared/ActionBar';
import { FinishingRadioGrid } from '../FinishingRadioGrid';
import { useFinishingSelection } from '../../../hooks/useFinishingSelection';

export function MatrixConfigurator({ category, inputState, updateInput, onAddItem, previewCalc }) {
    const { product, qty, sizeKey } = inputState;

    // Use shared finishing selection logic
    const { selectedFinishings, toggleFinishing, getSelectedIds } = useFinishingSelection(
        inputState.selectedFinishings || []
    );

    // Sync with parent state
    React.useEffect(() => {
        updateInput({ selectedFinishings });
    }, [selectedFinishings]);

    const handleProductSelect = (prod) => updateInput({ product: prod, sizeKey: null });

    const preview = previewCalc ? previewCalc() : { subtotal: 0 };
    const canAdd = product && sizeKey && preview.subtotal > 0;

    return (
        <div className="configurator">
            <div className="config-header">
                <h2>{category.name}</h2>
                <div className="logic-badge">MATRIX</div>
            </div>

            <div className="section-label">Pilih Produk</div>
            <ProductGrid
                products={category.products}
                selectedId={product?.id}
                onSelect={handleProductSelect}
                logicType={category.logic_type}
            />

            {product && (
                <div className="dynamic-inputs">
                    <div className="size-matrix-row">
                        {Object.keys(product.prices).map(key => (
                            <button
                                key={key}
                                className={`size-btn ${sizeKey === key ? 'active' : ''}`}
                                onClick={() => updateInput({ sizeKey: key })}
                            >
                                {key}
                                <small>Rp {product.prices[key].toLocaleString()}</small>
                            </button>
                        ))}
                    </div>

                    <div className="qty-row">
                        <label>Quantity</label>
                        <div className="qty-control">
                            <button onClick={() => updateInput({ qty: Math.max(1, qty - 1) })}>-</button>
                            <span>{qty}</span>
                            <button onClick={() => updateInput({ qty: qty + 1 })}>+</button>
                        </div>
                    </div>
                </div>
            )}

            {product && category.finishings?.length > 0 && (
                <FinishingRadioGrid
                    finishings={category.finishings}
                    selectedIds={getSelectedIds()}
                    onToggle={toggleFinishing}
                />
            )}

            <ActionBar total={preview.subtotal} breakdown={preview.breakdown} canAdd={canAdd} onAdd={onAddItem} />
        </div>
    );
}
