/**
 * RecentOrders Component
 * Display recent orders on dashboard
 */

import React from 'react';
import { formatRupiah } from '../../core/formatters';
import { formatDateTime } from '../../utils/dateHelpers';
import { ORDER_STATUS, PAYMENT_STATUS } from '../../core/constants';

export function RecentOrders({ orders }) {
    if (orders.length === 0) {
        return (
            <div className="empty-state">
                <p>📭 Belum ada pesanan</p>
            </div>
        );
    }

    return (
        <div className="recent-orders-list">
            {orders.map(order => {
                const statusConfig = ORDER_STATUS[order.productionStatus];
                const paymentConfig = PAYMENT_STATUS[order.paymentStatus];

                return (
                    <div key={order.id} className="recent-order-item">
                        <div className="order-item-header">
                            <div className="order-item-id">
                                <strong>#{order.id}</strong>
                                <span className="order-item-customer">{order.customerName}</span>
                            </div>
                            <div className="order-item-badges">
                                <span
                                    className="mini-badge"
                                    style={{ backgroundColor: statusConfig.color }}
                                >
                                    {statusConfig.label}
                                </span>
                                <span
                                    className="mini-badge"
                                    style={{ backgroundColor: paymentConfig.color }}
                                >
                                    {paymentConfig.label}
                                </span>
                            </div>
                        </div>
                        <div className="order-item-details">
                            <span className="order-item-date">{formatDateTime(order.createdAt)}</span>
                            <span className="order-item-amount">{formatRupiah(order.totalAmount)}</span>
                        </div>
                        {order.paymentStatus === 'DP' && (
                            <div className="order-item-pending">
                                Sisa: {formatRupiah(order.remainingAmount)}
                            </div>
                        )}
                    </div>
                );
            })}
        </div>
    );
}
