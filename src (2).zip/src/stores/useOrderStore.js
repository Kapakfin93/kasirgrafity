/**
 * Order Store - Zustand
 * State management for order/production tracking
 */

import { create } from 'zustand';
import db from '../data/db/schema';
import { Order } from '../data/models/Order';

export const useOrderStore = create((set, get) => ({
    // State
    orders: [],
    filteredOrders: [],
    currentFilter: 'ALL', // ALL | UNPAID | DP | PAID
    loading: false,
    error: null,

    // Actions
    loadOrders: async () => {
        set({ loading: true, error: null });
        try {
            const orders = await db.orders.toArray();
            const orderObjects = orders.map(o => Order.fromDB(o));

            set({
                orders: orderObjects,
                filteredOrders: orderObjects,
                loading: false
            });
        } catch (error) {
            set({ error: error.message, loading: false });
        }
    },

    createOrder: async (orderData) => {
        set({ loading: true, error: null });
        try {
            const order = new Order(orderData);
            order.updatePaymentStatus(); // Calculate payment status

            const id = await db.orders.add(order.toJSON());
            order.id = id;

            set(state => ({
                orders: [...state.orders, order],
                filteredOrders: get().applyFilter([...state.orders, order]),
                loading: false
            }));

            return order;
        } catch (error) {
            set({ error: error.message, loading: false });
            throw error;
        }
    },

    updateOrder: async (id, updates) => {
        set({ loading: true, error: null });
        try {
            await db.orders.update(id, updates);

            set(state => {
                const updatedOrders = state.orders.map(order => {
                    if (order.id === id) {
                        const updated = Order.fromDB({ ...order.toJSON(), ...updates });
                        updated.updatePaymentStatus();
                        return updated;
                    }
                    return order;
                });

                return {
                    orders: updatedOrders,
                    filteredOrders: get().applyFilter(updatedOrders),
                    loading: false
                };
            });
        } catch (error) {
            set({ error: error.message, loading: false });
            throw error;
        }
    },

    addPayment: async (orderId, amount) => {
        set({ loading: true, error: null });
        try {
            const order = get().orders.find(o => o.id === orderId);
            if (!order) {
                throw new Error('Order not found');
            }

            const newPaidAmount = order.paidAmount + amount;
            const updates = {
                paidAmount: newPaidAmount,
                dpAmount: order.dpAmount || (newPaidAmount < order.totalAmount ? amount : 0),
            };

            // Update payment status
            if (newPaidAmount >= order.totalAmount) {
                updates.paymentStatus = 'PAID';
                updates.remainingAmount = 0;
            } else if (newPaidAmount > 0) {
                updates.paymentStatus = 'DP';
                updates.remainingAmount = order.totalAmount - newPaidAmount;
            }

            await get().updateOrder(orderId, updates);
        } catch (error) {
            set({ error: error.message, loading: false });
            throw error;
        }
    },

    updateProductionStatus: async (orderId, status, assignedTo = null) => {
        const updates = { productionStatus: status };

        if (status === 'IN_PROGRESS' && assignedTo) {
            updates.assignedTo = assignedTo;
        }

        if (status === 'READY') {
            updates.completedAt = new Date().toISOString();
        }

        if (status === 'DELIVERED') {
            updates.deliveredAt = new Date().toISOString();
        }

        await get().updateOrder(orderId, updates);
    },

    filterByPaymentStatus: (status) => {
        set({ currentFilter: status });
        const filtered = get().applyFilter(get().orders);
        set({ filteredOrders: filtered });
    },

    applyFilter: (orders) => {
        const filter = get().currentFilter;
        if (filter === 'ALL') return orders;
        return orders.filter(order => order.paymentStatus === filter);
    },

    getOrdersByStatus: (status) => {
        return get().orders.filter(order => order.productionStatus === status);
    },

    getOrdersByPaymentStatus: (status) => {
        return get().orders.filter(order => order.paymentStatus === status);
    },

    getPendingOrders: () => {
        return get().orders.filter(order =>
            order.productionStatus !== 'DELIVERED' &&
            order.paymentStatus !== 'PAID'
        );
    },

    getOrderById: (id) => {
        return get().orders.find(order => order.id === id);
    },

    clearError: () => {
        set({ error: null });
    },
}));
